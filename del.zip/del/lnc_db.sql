CREATE TABLE IF NOT EXISTS `chat_table` (
`chat_id` int(11) NOT NULL,
  `chat_username` varchar(100) NOT NULL,
  `chat_message` text NOT NULL,
  `chat_user_photo` varchar(100) NOT NULL,
  `chat_date` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `lesson_category_table` (
`lesson_category_id` int(11) NOT NULL,
  `lesson_category_title` varchar(80) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `lesson_table` (
`lesson_id` int(11) NOT NULL,
  `lesson_title` varchar(100) NOT NULL,
  `lesson_details` text NOT NULL,
  `lesson_media` varchar(100) NOT NULL,
  `lesson_tags` varchar(100) NOT NULL,
  `lesson_uploader` varchar(100) NOT NULL,
  `lesson_category` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `task_table` (
`task_id` int(11) NOT NULL,
  `task_title` varchar(100) NOT NULL,
  `task_details` text NOT NULL,
  `task_input_file` varchar(200) NOT NULL,
  `task_output_file` varchar(200) NOT NULL,
  `task_hints` varchar(400) NOT NULL,
  `task_media` varchar(200) NOT NULL,
  `task_point` varchar(50) NOT NULL,
  `task_uploader` varchar(100) NOT NULL,
  `task_category` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `user_ranklist` (
  `ranklist_username` varchar(100) NOT NULL,
  `number_of_ac` int(11) NOT NULL DEFAULT '0',
  `number_of_submissions` int(11) NOT NULL DEFAULT '0',
  `date_of_last_submission` varchar(100) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `user_table` (
  `user_username` varchar(50) NOT NULL,
  `user_password` varchar(100) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_fullname` varchar(100) NOT NULL,
  `user_city` varchar(50) NOT NULL,
  `user_country` varchar(50) NOT NULL,
  `user_occupation` varchar(100) NOT NULL,
  `user_institute` varchar(100) NOT NULL,
  `user_phone` varchar(50) NOT NULL,
  `user_website` varchar(50) NOT NULL,
  `user_github` varchar(50) NOT NULL,
  `user_bio` varchar(250) NOT NULL,
  `user_photo` varchar(100) NOT NULL,
  `user_role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `user_task_table` (
`submission_id` int(11) NOT NULL,
  `submission_username` varchar(100) NOT NULL,
  `submission_task_id` varchar(100) NOT NULL,
  `submission_task_title` varchar(100) NOT NULL,
  `submission_task_category` varchar(100) NOT NULL,
  `submission_verdict` varchar(100) NOT NULL,
  `submission_code` text NOT NULL,
  `submission_date` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;


--
-- Indexes for table `chat_table`
--
ALTER TABLE `chat_table`
 ADD PRIMARY KEY (`chat_id`);

--
-- Indexes for table `lesson_category_table`
--
ALTER TABLE `lesson_category_table`
 ADD PRIMARY KEY (`lesson_category_id`);

--
-- Indexes for table `lesson_table`
--
ALTER TABLE `lesson_table`
 ADD PRIMARY KEY (`lesson_id`);

--
-- Indexes for table `task_table`
--
ALTER TABLE `task_table`
 ADD PRIMARY KEY (`task_id`);

--
-- Indexes for table `user_ranklist`
--
ALTER TABLE `user_ranklist`
 ADD PRIMARY KEY (`ranklist_username`);

--
-- Indexes for table `user_table`
--
ALTER TABLE `user_table`
 ADD PRIMARY KEY (`user_username`);

--
-- Indexes for table `user_task_table`
--
ALTER TABLE `user_task_table`
 ADD PRIMARY KEY (`submission_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chat_table`
--
ALTER TABLE `chat_table`
MODIFY `chat_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `lesson_category_table`
--
ALTER TABLE `lesson_category_table`
MODIFY `lesson_category_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `lesson_table`
--
ALTER TABLE `lesson_table`
MODIFY `lesson_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `task_table`
--
ALTER TABLE `task_table`
MODIFY `task_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `user_task_table`
--
ALTER TABLE `user_task_table`
MODIFY `submission_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
