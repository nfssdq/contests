-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u1build0.15.04.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 22, 2016 at 01:18 AM
-- Server version: 5.6.27-0ubuntu0.15.04.1
-- PHP Version: 5.6.4-4ubuntu6.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `lnc_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `chat_table`
--

CREATE TABLE IF NOT EXISTS `chat_table` (
`chat_id` int(11) NOT NULL,
  `chat_username` varchar(100) NOT NULL,
  `chat_message` text NOT NULL,
  `chat_user_photo` varchar(100) NOT NULL,
  `chat_date` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lesson_category_table`
--

CREATE TABLE IF NOT EXISTS `lesson_category_table` (
`lesson_category_id` int(11) NOT NULL,
  `lesson_category_title` varchar(80) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lesson_category_table`
--

INSERT INTO `lesson_category_table` (`lesson_category_id`, `lesson_category_title`) VALUES
(1, 'Introduction'),
(2, 'Data Types'),
(3, 'Variables'),
(4, 'Operators'),
(5, 'Conditions'),
(6, 'Loops'),
(7, 'Functions'),
(8, 'Arrays'),
(9, 'String'),
(10, 'Scope'),
(11, 'Mathematics'),
(12, 'Input Output'),
(13, 'File I/O'),
(14, 'Structures'),
(15, 'Pointers'),
(16, 'Pre Processors');

-- --------------------------------------------------------

--
-- Table structure for table `lesson_table`
--

CREATE TABLE IF NOT EXISTS `lesson_table` (
`lesson_id` int(11) NOT NULL,
  `lesson_title` varchar(100) NOT NULL,
  `lesson_details` text NOT NULL,
  `lesson_media` varchar(100) NOT NULL,
  `lesson_tags` varchar(100) NOT NULL,
  `lesson_uploader` varchar(100) NOT NULL,
  `lesson_category` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lesson_table`
--

INSERT INTO `lesson_table` (`lesson_id`, `lesson_title`, `lesson_details`, `lesson_media`, `lesson_tags`, `lesson_uploader`, `lesson_category`) VALUES
(3, 'History of C', '&lt;h3 class=&quot;center_text&quot;&gt;Welcome to learn C programming&lt;/h3&gt;\r\n&lt;p&gt;&lt;strong&gt;C&lt;/strong&gt; is a computer programming language developed in 1972 by &lt;strong&gt;Dennis M. Ritchie&lt;/strong&gt; at the Bell Telephone Laboratories to develop the UNIX Operating System. C is a simple and &lt;strong&gt;structure oriented&lt;/strong&gt; programming language.&lt;/p&gt;\r\n&lt;p&gt;C is also called &lt;strong&gt;mother Language&lt;/strong&gt; of all programming Language. It is the most widely use computer programming language, This language is used for develop system software and Operating System. All other programming languages were derived directly or indirectly from C programming concepts.&lt;/p&gt;\r\n&lt;h3 class=&quot;center_text&quot;&gt;History of C&lt;/h3&gt;\r\n&lt;p&gt;C language is developed by &lt;strong&gt;Mr. Dennis Ritchie&lt;/strong&gt;  in the year 1972 at bell laboratory at USA, C is a simple and structure Oriented Programming Language.&lt;/p&gt;\r\n&lt;p&gt;In the year 1988 C programming language standardized by ANSI (American national standard institute), that version is called ANSI-C. In the year of 2000 C programming language standardized by ISO that version is called C-99. All other programming languages were derived directly or indirectly from C programming concepts.&lt;/p&gt;\r\n&lt;h3 class=&quot;center_text&quot;&gt;Prerequisites&lt;/h3&gt;\r\n&lt;p&gt;Before learning C Programming language no need of knowledge of any Computer programming language, C is the basic of all high level programming languages. C is also called mother Language.&lt;/p&gt;\r\n&lt;!-- Bottom preview or next button --&gt;\r\n&lt;hr /&gt;', 'lesson_dir/3_media.jpg', 'Introduction#History#ANSI-C', 'nfs', 'Introduction'),
(4, 'Applications of C', '&lt;h3 class=&quot;center_text&quot;&gt;Applications of C&lt;/h3&gt;\r\n&lt;p&gt;Mainly C Language is used for Develop Desktop application and system software. Some application of C language are given below.&lt;/p&gt;\r\n&lt;ul&gt;\r\n&lt;li&gt;C programming language can be used to design the system software like operating system and Compiler.&lt;/li&gt;\r\n&lt;li&gt;To develop application software like database and spread sheets.&lt;/li&gt;\r\n&lt;li&gt;For Develop Graphical related application like computer and mobile games.&lt;/li&gt;\r\n&lt;li&gt;To evaluate any kind of mathematical equation use c language.&lt;/li&gt;\r\n&lt;li&gt;C programming language can be used to design the compilers.&lt;/li&gt;\r\n&lt;li&gt;UNIX Kernal is completely developed in C Language.&lt;/li&gt;\r\n&lt;li&gt;&lt;strong&gt;For Creating Compilers&lt;/strong&gt; of different Languages which can take input from other language and convert it into lower level machine dependent language.&lt;/li&gt;\r\n&lt;li&gt;C programming language can be used to design Operating System.&lt;/li&gt;\r\n&lt;li&gt;C programming language can be used to design Network Devices.&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;!-- Bottom preview or next button --&gt;\r\n&lt;hr /&gt;', '', 'Applications#Introduction', 'nfs', 'Introduction');

-- --------------------------------------------------------

--
-- Table structure for table `task_table`
--

CREATE TABLE IF NOT EXISTS `task_table` (
`task_id` int(11) NOT NULL,
  `task_title` varchar(100) NOT NULL,
  `task_details` text NOT NULL,
  `task_input_file` varchar(200) NOT NULL,
  `task_output_file` varchar(200) NOT NULL,
  `task_hints` varchar(400) NOT NULL,
  `task_media` varchar(200) NOT NULL,
  `task_point` varchar(50) NOT NULL,
  `task_uploader` varchar(100) NOT NULL,
  `task_category` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `task_table`
--

INSERT INTO `task_table` (`task_id`, `task_title`, `task_details`, `task_input_file`, `task_output_file`, `task_hints`, `task_media`, `task_point`, `task_uploader`, `task_category`) VALUES
(10, 'Hello World', 'You are given a program below. Change it in appropriate place so that it prints &quot;Let''s learn programming&quot;.\r\n&lt;pre&gt;\r\n&lt;code&gt; \r\n#include&lt;stdio.h&gt;\r\nint main(){\r\n    printf(&quot;Hello World\\n&quot;);\r\n    return 0;\r\n}\r\n&lt;/code&gt;\r\n&lt;/pre&gt;', 'task_dir/10_input.in', 'task_dir/10_output.out', 'Check semicolon#Ensure to add newline ''n''#Check spelling#Don''t forget to add header file', '', '5', 'arsho', 'Introduction'),
(13, 'Find the type', 'There are several data given below. Can you determine their types? I will give you a hint, they are either int, float or char.&lt;br&gt;\r\n1. a&lt;br&gt;\r\n2. 2016&lt;br&gt;\r\n3. 44.9&lt;br&gt;\r\n4. 3.14159265&lt;br&gt;\r\n5. 1000000007&lt;br&gt;\r\nYou will have to print 5 lines. In each line print the datatype of the data in that line. If it is an integer then print &quot;int&quot;, if a real number then &quot;float&quot;, otherwise &quot;char&quot;.', 'task_dir/13_input.in', 'task_dir/13_output.out', 'Check semicolon#Ensure to add newline ''n''#Check spelling#Don''t forget to add header file', '', '10', 'arsho', 'Data Types');

-- --------------------------------------------------------

--
-- Table structure for table `user_ranklist`
--

CREATE TABLE IF NOT EXISTS `user_ranklist` (
  `ranklist_username` varchar(100) NOT NULL,
  `number_of_ac` int(11) NOT NULL DEFAULT '0',
  `number_of_submissions` int(11) NOT NULL DEFAULT '0',
  `date_of_last_submission` varchar(100) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_ranklist`
--

INSERT INTO `user_ranklist` (`ranklist_username`, `number_of_ac`, `number_of_submissions`, `date_of_last_submission`) VALUES
('arsho', 1, 1, '1453394701'),
('md_aslam', 0, 0, '0'),
('nfs', 2, 3, '1453395997');

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

CREATE TABLE IF NOT EXISTS `user_table` (
  `user_username` varchar(50) NOT NULL,
  `user_password` varchar(100) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_fullname` varchar(100) NOT NULL,
  `user_city` varchar(50) NOT NULL,
  `user_country` varchar(50) NOT NULL,
  `user_occupation` varchar(100) NOT NULL,
  `user_institute` varchar(100) NOT NULL,
  `user_phone` varchar(50) NOT NULL,
  `user_website` varchar(50) NOT NULL,
  `user_github` varchar(50) NOT NULL,
  `user_bio` varchar(250) NOT NULL,
  `user_photo` varchar(100) NOT NULL,
  `user_role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`user_username`, `user_password`, `user_email`, `user_fullname`, `user_city`, `user_country`, `user_occupation`, `user_institute`, `user_phone`, `user_website`, `user_github`, `user_bio`, `user_photo`, `user_role`) VALUES
('arsho', 'c4ca4238a0b923820dcc509a6f75849b', 'shovon.sylhet@gmail.com', '', '', 'BD', '', '', '', '', '', '', 'user_image_dir/arsho_image.png', 'Admin'),
('md_aslam', '927239d02220cef7750ccd6aaca50f48', 'aslam_iit_ju@outlook.com', '', '', '', '', '', '', '', '', '', 'user_image_dir/user.png', 'User'),
('nfs', 'c4ca4238a0b923820dcc509a6f75849b', 'nfssdq@gmail.com', '', '', 'BD', '', '', '', '', '', '', 'user_image_dir/nfs_image.png', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `user_task_table`
--

CREATE TABLE IF NOT EXISTS `user_task_table` (
`submission_id` int(11) NOT NULL,
  `submission_username` varchar(100) NOT NULL,
  `submission_task_id` varchar(100) NOT NULL,
  `submission_task_title` varchar(100) NOT NULL,
  `submission_task_category` varchar(100) NOT NULL,
  `submission_verdict` varchar(100) NOT NULL,
  `submission_code` text NOT NULL,
  `submission_date` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_task_table`
--

INSERT INTO `user_task_table` (`submission_id`, `submission_username`, `submission_task_id`, `submission_task_title`, `submission_task_category`, `submission_verdict`, `submission_code`, `submission_date`) VALUES
(24, 'nfs', '13', 'Find the type', 'Data Types', 'Accepted', '#include &lt;stdio.h&gt;\n\nint main() {    \n    printf(&quot;char\\n&quot;);\n    printf(&quot;int\\n&quot;);\n    printf(&quot;float\\n&quot;);\n    printf(&quot;float\\n&quot;);\n    printf(&quot;int\\n&quot;);\n    \n    return 0;\n}', '1453395997');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chat_table`
--
ALTER TABLE `chat_table`
 ADD PRIMARY KEY (`chat_id`);

--
-- Indexes for table `lesson_category_table`
--
ALTER TABLE `lesson_category_table`
 ADD PRIMARY KEY (`lesson_category_id`);

--
-- Indexes for table `lesson_table`
--
ALTER TABLE `lesson_table`
 ADD PRIMARY KEY (`lesson_id`);

--
-- Indexes for table `task_table`
--
ALTER TABLE `task_table`
 ADD PRIMARY KEY (`task_id`);

--
-- Indexes for table `user_ranklist`
--
ALTER TABLE `user_ranklist`
 ADD PRIMARY KEY (`ranklist_username`);

--
-- Indexes for table `user_table`
--
ALTER TABLE `user_table`
 ADD PRIMARY KEY (`user_username`);

--
-- Indexes for table `user_task_table`
--
ALTER TABLE `user_task_table`
 ADD PRIMARY KEY (`submission_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chat_table`
--
ALTER TABLE `chat_table`
MODIFY `chat_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `lesson_category_table`
--
ALTER TABLE `lesson_category_table`
MODIFY `lesson_category_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `lesson_table`
--
ALTER TABLE `lesson_table`
MODIFY `lesson_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `task_table`
--
ALTER TABLE `task_table`
MODIFY `task_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `user_task_table`
--
ALTER TABLE `user_task_table`
MODIFY `submission_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
